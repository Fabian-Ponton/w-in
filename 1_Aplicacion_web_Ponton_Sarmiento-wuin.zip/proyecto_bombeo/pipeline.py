"""
Pipeline del proyecto final de ML: bombeo solar de agua en Uribia, La Guajira.

Decisión que se mejora:
    Cada tarde el operador del acueducto solar decide cuántos m³ de agua pedir
    en carrotanque para el día siguiente. Si pide de menos, al día siguiente
    falta agua y toca un carrotanque de emergencia (más caro). Si pide de más,
    paga agua que no hacía falta.

Uso:
    python pipeline.py datos/<archivo NASA POWER>.csv
    python pipeline.py --descargar  (baja de NASA POWER los datos hasta hoy y reentrena)
    python pipeline.py              (sin CSV: usa datos SINTÉTICOS, solo para pruebas)

Salidas:
    modelo/resultados.json   métricas, tabla de costos, datos para la app
    modelo/modelo.json       modelo exportado (árboles) para la app web
"""
import json
import sys
import urllib.request
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

RAIZ = Path(__file__).resolve().parent
SALIDA = RAIZ / "modelo"
SEMILLA = 42

# ----------------------------------------------------------------------------
# Supuestos del sistema (escenario típico de un acueducto solar comunitario).
# Todos se declaran en la nota de transparencia de la app.
# ----------------------------------------------------------------------------
SISTEMA = {
    "potencia_fv_kwp": 3.0,          # generador fotovoltaico
    "rendimiento_base": 0.85,        # pérdidas de cableado, suciedad, inversor
    "coef_temp_por_c": -0.004,       # pérdida de potencia por °C sobre 25 °C
    "eficiencia_bomba": 0.45,        # motobomba sumergible + variador
    "altura_dinamica_m": 60.0,       # altura dinámica total (pozo + tanque)
    "demanda_m3_dia": 33.0,          # ~550 personas x 60 L/persona/día
    "tanque_m3": 20.0,               # capacidad del tanque elevado
    "costo_carrotanque_programado_cop_m3": 30000,
    "costo_carrotanque_emergencia_cop_m3": 80000,
}


# ----------------------------------------------------------------------------
# 1. Carga de datos
# ----------------------------------------------------------------------------
def cargar_nasa_power(ruta):
    """Lee el CSV de NASA POWER saltando el encabezado -BEGIN HEADER- ... -END HEADER-."""
    lineas = Path(ruta).read_text(encoding="utf-8", errors="replace").splitlines()
    fin = next((i for i, l in enumerate(lineas) if l.strip() == "-END HEADER-"), -1)
    meta = {"encabezado": [l.strip() for l in lineas[: fin + 1]] if fin >= 0 else []}
    df = pd.read_csv(ruta, skiprows=fin + 1)
    df["fecha"] = pd.to_datetime(dict(year=df.YEAR, month=df.MO, day=df.DY))
    return df, meta


LATITUD, LONGITUD = 11.71, -72.27
API_NASA = ("https://power.larc.nasa.gov/api/temporal/daily/point?parameters="
            "ALLSKY_SFC_SW_DWN,T2M,WS2M,RH2M,PRECTOTCORR&community=RE"
            "&longitude={lon}&latitude={lat}&start={ini}&end={fin}&format=CSV&time-standard=LST")


def descargar_nasa_power(inicio="20150101"):
    """Descarga la serie diaria de NASA POWER hasta ayer y la guarda en datos/.

    NASA publica la radiación con unos días de retraso: los últimos días llegan
    como -999 y se recortan para no inventar datos.
    """
    fin = (date.today() - timedelta(days=1)).strftime("%Y%m%d")
    url = API_NASA.format(lon=LONGITUD, lat=LATITUD, ini=inicio, fin=fin)
    print(f"Descargando NASA POWER {inicio} a {fin} ...")
    with urllib.request.urlopen(url, timeout=120) as r:
        texto = r.read().decode("utf-8")
    ruta = RAIZ / "datos" / f"POWER_Uribia_{inicio}_{fin}.csv"
    ruta.parent.mkdir(exist_ok=True)
    ruta.write_text(texto, encoding="utf-8")
    df, meta = cargar_nasa_power(ruta)
    validos = df.index[(df[VARIABLES] != -999).all(axis=1)]
    recortados = len(df) - (validos.max() + 1)
    df = df.loc[: validos.max()].reset_index(drop=True)
    print(f"Guardado {ruta.name}: último día completo {df.fecha.max():%Y-%m-%d}"
          f" ({recortados} días recientes aún sin publicar).")
    return df, meta, ruta


def generar_sinteticos():
    """Solo para probar el código sin el CSV real. La app mostrará un aviso."""
    rng = np.random.default_rng(SEMILLA)
    fechas = pd.date_range("2015-01-01", "2025-12-31", freq="D")
    doy = fechas.dayofyear.values
    ghi = 5.6 + 0.5 * np.sin(2 * np.pi * (doy - 80) / 365) + rng.normal(0, 0.8, len(fechas))
    df = pd.DataFrame({
        "fecha": fechas,
        "ALLSKY_SFC_SW_DWN": np.clip(ghi, 1.5, 7.7),
        "T2M": 28.4 + rng.normal(0, 0.8, len(fechas)),
        "WS2M": np.clip(2.2 + rng.normal(0, 0.7, len(fechas)), 0.3, None),
        "RH2M": np.clip(72 + rng.normal(0, 6, len(fechas)), 50, 96),
        "PRECTOTCORR": rng.exponential(3, len(fechas)),
    })
    return df, {"encabezado": []}


# ----------------------------------------------------------------------------
# 2. Exploración y limpieza (cada decisión queda registrada)
# ----------------------------------------------------------------------------
VARIABLES = ["ALLSKY_SFC_SW_DWN", "T2M", "WS2M", "RH2M", "PRECTOTCORR"]


def limpiar(df):
    reg = []
    df = df.sort_values("fecha").drop_duplicates("fecha").reset_index(drop=True)
    n0 = len(df)

    # Faltantes: NASA POWER marca con -999
    faltantes = {v: int((df[v] == -999).sum()) for v in VARIABLES}
    df[VARIABLES] = df[VARIABLES].replace(-999, np.nan)
    reg.append(f"Valores -999 (faltantes) por variable: {faltantes}.")

    # Huecos de calendario
    completo = pd.date_range(df.fecha.min(), df.fecha.max(), freq="D")
    huecos = len(completo) - len(df)
    df = df.set_index("fecha").reindex(completo).rename_axis("fecha").reset_index()
    reg.append(f"Días ausentes en el calendario: {huecos}.")

    # Imputación por interpolación lineal en el tiempo (máx. 3 días seguidos)
    n_nan = int(df[VARIABLES].isna().sum().sum())
    df[VARIABLES] = df[VARIABLES].interpolate(limit=3, limit_direction="both")
    df = df.dropna(subset=VARIABLES).reset_index(drop=True)
    reg.append(f"Celdas imputadas por interpolación lineal (máx. 3 días): {n_nan}.")

    # Atípicos por rango físico
    fuera = int(((df.ALLSKY_SFC_SW_DWN < 0) | (df.ALLSKY_SFC_SW_DWN > 9)).sum())
    reg.append(f"Radiación fuera del rango físico 0-9 kWh/m²/día: {fuera} días.")

    # Precipitación extrema: se conserva (puede ser real) pero se usa log1p para
    # que un solo día extremo no domine el modelo.
    p999 = df.PRECTOTCORR.quantile(0.999)
    extremos = df.loc[df.PRECTOTCORR > p999, ["fecha", "PRECTOTCORR"]]
    reg.append(
        "Precipitación extrema (> percentil 99.9 = %.1f mm): %s. Se conservan y se usa log(1+p) como variable."
        % (p999, ", ".join(f"{f:%Y-%m-%d} ({p:.0f} mm)" for f, p in extremos.values))
    )
    reg.append(f"Filas finales: {len(df)} (inicio {n0}).")
    return df, reg


def describir(df):
    d = df[VARIABLES].describe().T[["mean", "std", "min", "max"]].round(3)
    mensual = df.groupby(df.fecha.dt.month).ALLSKY_SFC_SW_DWN.agg(["mean", "std", "min"]).round(3)
    return {
        "estadisticos": {v: d.loc[v].to_dict() for v in VARIABLES},
        "radiacion_mensual": {int(m): r.to_dict() for m, r in mensual.iterrows()},
        "autocorrelacion_radiacion_1dia": round(float(df.ALLSKY_SFC_SW_DWN.autocorr(1)), 3),
    }


# ----------------------------------------------------------------------------
# 3. Física: radiación -> agua bombeada
# ----------------------------------------------------------------------------
def volumen_bombeado(ghi, t2m, s=SISTEMA):
    """m³/día que el sistema bombea con una radiación diaria dada (kWh/m²/día)."""
    t_celda = np.asarray(t2m) + 25.0
    factor_t = 1 + s["coef_temp_por_c"] * (t_celda - 25.0)
    e_fv = s["potencia_fv_kwp"] * np.asarray(ghi) * s["rendimiento_base"] * factor_t  # kWh
    e_hid = e_fv * s["eficiencia_bomba"]
    return e_hid * 3.6e6 / (1000 * 9.81 * s["altura_dinamica_m"])


# ----------------------------------------------------------------------------
# 4. Variables (solo información disponible la tarde del día t)
# ----------------------------------------------------------------------------
CARACTERISTICAS = [
    "ghi_hoy", "ghi_ayer", "ghi_anteayer", "ghi_media7", "ghi_std7",
    "t2m_hoy", "rh2m_hoy", "ws2m_hoy", "lluvia_log_hoy", "rh2m_cambio",
    "doy_sin", "doy_cos",
]


def construir_variables(df):
    x = pd.DataFrame({"fecha": df.fecha})
    g = df.ALLSKY_SFC_SW_DWN
    x["ghi_hoy"] = g
    x["ghi_ayer"] = g.shift(1)
    x["ghi_anteayer"] = g.shift(2)
    x["ghi_media7"] = g.rolling(7).mean()
    x["ghi_std7"] = g.rolling(7).std()
    x["t2m_hoy"] = df.T2M
    x["rh2m_hoy"] = df.RH2M
    x["ws2m_hoy"] = df.WS2M
    x["lluvia_log_hoy"] = np.log1p(df.PRECTOTCORR)
    x["rh2m_cambio"] = df.RH2M - df.RH2M.shift(1)
    doy = (df.fecha.dt.dayofyear + 1).values  # día objetivo = mañana
    x["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    x["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    # Objetivo: radiación de MAÑANA
    x["objetivo_ghi_manana"] = g.shift(-1)
    x["t2m_manana"] = df.T2M.shift(-1)
    return x.dropna().reset_index(drop=True)


def particion_cronologica(x):
    n = len(x)
    i1, i2 = int(n * 0.6), int(n * 0.8)
    return x.iloc[:i1], x.iloc[i1:i2], x.iloc[i2:]


def metricas(y, p):
    return {
        "MAE": round(float(mean_absolute_error(y, p)), 4),
        "RMSE": round(float(np.sqrt(mean_squared_error(y, p))), 4),
        "R2": round(float(r2_score(y, p)), 4),
    }


# ----------------------------------------------------------------------------
# 5. Simulación de la decisión con tanque (costos en pesos)
# ----------------------------------------------------------------------------
def simular(df_eval, ghi_previsto, s=SISTEMA, oraculo=False):
    """Simula día a día: pedido de la tarde -> bombeo real -> déficit -> tanque."""
    D, cap = s["demanda_m3_dia"], s["tanque_m3"]
    c_prog, c_emer = s["costo_carrotanque_programado_cop_m3"], s["costo_carrotanque_emergencia_cop_m3"]
    v_real = volumen_bombeado(df_eval.objetivo_ghi_manana.values, df_eval.t2m_manana.values, s)
    t_prev = df_eval.t2m_manana.values if oraculo else df_eval.t2m_hoy.values
    v_prev = None if ghi_previsto is None else volumen_bombeado(ghi_previsto, t_prev, s)
    nivel = cap / 2
    m3_prog = m3_emer = 0.0
    dias_deficit = 0
    for i in range(len(df_eval)):
        if v_prev is None:
            pedido = 0.0
        else:
            pedido = max(0.0, D - v_prev[i] - nivel)
        disponible = nivel + v_real[i] + pedido
        entregado = min(D, disponible)
        deficit = D - entregado
        if deficit > 1e-9:
            dias_deficit += 1
        m3_prog += pedido
        m3_emer += deficit
        nivel = min(cap, disponible - entregado)
    costo = m3_prog * c_prog + m3_emer * c_emer
    return {
        "m3_programados": round(m3_prog, 1),
        "m3_emergencia": round(m3_emer, 1),
        "dias_con_emergencia": dias_deficit,
        "costo_total_cop": int(round(costo)),
    }


# ----------------------------------------------------------------------------
# 6. Exportar árboles para la app (inferencia en JavaScript)
# ----------------------------------------------------------------------------
def exportar_arbol(t):
    tr = t.tree_
    return {
        "l": tr.children_left.tolist(), "r": tr.children_right.tolist(),
        "f": tr.feature.tolist(), "t": tr.threshold.tolist(),
        "v": np.round(tr.value[:, 0, 0], 6).tolist(),
    }


def exportar_modelo(nombre, m):
    if nombre == "Gradient Boosting":
        return {"tipo": "gbr", "init": float(m.init_.constant_[0][0]),
                "lr": m.learning_rate, "arboles": [exportar_arbol(e[0]) for e in m.estimators_]}
    if nombre == "Random Forest":
        return {"tipo": "rf", "arboles": [exportar_arbol(e) for e in m.estimators_]}
    sc, rg = m.named_steps["standardscaler"], m.named_steps["ridge"]
    return {"tipo": "lineal", "media": sc.mean_.tolist(), "escala": sc.scale_.tolist(),
            "coef": rg.coef_.tolist(), "intercepto": float(rg.intercept_)}


# ----------------------------------------------------------------------------
def main():
    sinteticos = len(sys.argv) < 2
    if not sinteticos and sys.argv[1] == "--descargar":
        crudo, meta, ruta = descargar_nasa_power()
        fuente = f"NASA POWER (diario, real, descargado el {date.today():%Y-%m-%d}): {ruta.name}"
    elif sinteticos:
        print("AVISO: no se indicó CSV; se usan datos SINTÉTICOS (solo para pruebas).")
        crudo, meta = generar_sinteticos()
        fuente = "Datos sintéticos generados por pipeline.py (NO reales)"
    else:
        crudo, meta = cargar_nasa_power(sys.argv[1])
        fuente = f"NASA POWER (diario, real): {Path(sys.argv[1]).name}"
    ubicacion = next((l for l in meta["encabezado"] if l.lower().startswith("location")), "")

    df, registro = limpiar(crudo)
    exploracion = describir(df)
    x = construir_variables(df)
    tr, va, te = particion_cronologica(x)
    Xtr, ytr = tr[CARACTERISTICAS].values, tr.objetivo_ghi_manana.values
    Xva, yva = va[CARACTERISTICAS].values, va.objetivo_ghi_manana.values
    Xte, yte = te[CARACTERISTICAS].values, te.objetivo_ghi_manana.values

    # Líneas base
    clim = tr.groupby(tr.fecha.dt.month).objetivo_ghi_manana.mean()
    def p_clim(d):
        return (d.fecha + pd.Timedelta(days=1)).dt.month.map(clim).values
    bases = {
        "Persistencia (mañana = hoy)": (va.ghi_hoy.values, te.ghi_hoy.values),
        "Climatología mensual": (p_clim(va), p_clim(te)),
    }

    # Modelos candidatos (se eligen con validación, nunca con prueba)
    candidatos = {
        "Regresión Ridge": make_pipeline(StandardScaler(), Ridge(alpha=1.0)),
        "Random Forest": RandomForestRegressor(n_estimators=150, max_depth=8, min_samples_leaf=10,
                                               random_state=SEMILLA, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.03,
                                                       subsample=0.8, min_samples_leaf=15,
                                                       random_state=SEMILLA),
    }
    tabla = []
    for nombre, (pv, pt) in bases.items():
        tabla.append({"modelo": nombre, "tipo": "línea base",
                      "validacion": metricas(yva, pv), "prueba": metricas(yte, pt)})
    pred_va, pred_te = {}, {}
    for nombre, m in candidatos.items():
        m.fit(Xtr, ytr)
        pred_va[nombre], pred_te[nombre] = m.predict(Xva), m.predict(Xte)
        tabla.append({"modelo": nombre, "tipo": "ML",
                      "validacion": metricas(yva, pred_va[nombre]), "prueba": metricas(yte, pred_te[nombre])})

    elegido = min(candidatos, key=lambda n: mean_absolute_error(yva, pred_va[n]))
    modelo = candidatos[elegido]
    for fila in tabla:
        fila["elegido"] = fila["modelo"] == elegido

    # Incertidumbre: cuantiles de los residuos en validación
    resid = yva - pred_va[elegido]
    cuantiles = {str(q): round(float(np.quantile(resid, q)), 4) for q in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)}

    # Elegir el cuantil de decisión (qué tan conservador) con VALIDACIÓN
    grilla = np.round(np.arange(0.05, 0.96, 0.05), 2)
    costos_q = {float(q): simular(va, pred_va[elegido] + np.quantile(resid, q))["costo_total_cop"] for q in grilla}
    q_opt = min(costos_q, key=costos_q.get)
    ajuste = float(np.quantile(resid, q_opt))

    # Tabla de costos en PRUEBA (datos nunca vistos)
    dias_te = len(te)
    politicas = [
        ("Sin pronóstico (solo carrotanque de emergencia)", simular(te, None)),
        ("Climatología (promedio del mes)", simular(te, p_clim(te))),
        ("Persistencia (mañana = hoy)", simular(te, te.ghi_hoy.values)),
        (f"{elegido} (mediana)", simular(te, pred_te[elegido])),
        (f"{elegido} + margen de seguridad (cuantil {q_opt:.2f})", simular(te, pred_te[elegido] + ajuste)),
        ("Pronóstico perfecto (límite teórico)", simular(te, yte, oraculo=True)),
    ]
    ref = politicas[2][1]["costo_total_cop"]
    tabla_costos = []
    for nombre, r in politicas:
        r = dict(r)
        r["politica"] = nombre
        r["costo_anual_cop"] = int(round(r["costo_total_cop"] * 365 / dias_te))
        r["ahorro_vs_persistencia_cop"] = ref - r["costo_total_cop"]
        r["ahorro_vs_persistencia_pct"] = round(100 * (ref - r["costo_total_cop"]) / ref, 1) if ref else 0.0
        tabla_costos.append(r)

    # Importancia de variables (si es de árboles)
    importancia = {}
    if hasattr(modelo, "feature_importances_"):
        importancia = {c: round(float(v), 4) for c, v in
                       sorted(zip(CARACTERISTICAS, modelo.feature_importances_), key=lambda z: -z[1])}

    # Serie de prueba para graficar en la app
    serie = pd.DataFrame({
        "fecha": te.fecha.dt.strftime("%Y-%m-%d"),
        "ghi_hoy": te.ghi_hoy.round(3), "real_manana": te.objetivo_ghi_manana.round(3),
        "pred": np.round(pred_te[elegido], 3), "persistencia": te.ghi_hoy.round(3),
    })
    # Escenarios: últimos días con sus variables (para la pantalla de entrada)
    # Escenarios: todos los días de prueba, con los 7 días de radiación y el clima crudo
    g_por_fecha = df.set_index("fecha")
    escenarios = []
    for _, r in te.iterrows():
        ult7 = g_por_fecha.loc[r.fecha - pd.Timedelta(days=6): r.fecha]
        escenarios.append({
            "fecha": f"{r.fecha:%Y-%m-%d}", **{c: round(float(r[c]), 7) for c in CARACTERISTICAS},
            "t2m_hoy": round(float(r.t2m_hoy), 2), "real_manana": round(float(r.objetivo_ghi_manana), 3),
            "ghi7": [round(float(v), 4) for v in ult7.ALLSKY_SFC_SW_DWN.values[::-1]],
            "rh_ayer": round(float(r.rh2m_hoy - r.rh2m_cambio), 2),
            "lluvia_mm": round(float(np.expm1(r.lluvia_log_hoy)), 2),
        })

    mae_m = mean_absolute_error(yte, pred_te[elegido])
    mae_p = mean_absolute_error(yte, te.ghi_hoy.values)
    resultados = {
        "datos_sinteticos": sinteticos,
        "fuente_datos": fuente,
        "ubicacion": ubicacion,
        "periodo": f"{df.fecha.min():%Y-%m-%d} a {df.fecha.max():%Y-%m-%d}",
        "n_dias": int(len(df)),
        "decision": "Cuántos m³ pedir en carrotanque programado para mañana",
        "sistema": SISTEMA,
        "limpieza": registro,
        "exploracion": exploracion,
        "particion": {
            "entrenamiento": f"{tr.fecha.min():%Y-%m-%d} a {tr.fecha.max():%Y-%m-%d} ({len(tr)} días)",
            "validacion": f"{va.fecha.min():%Y-%m-%d} a {va.fecha.max():%Y-%m-%d} ({len(va)} días)",
            "prueba": f"{te.fecha.min():%Y-%m-%d} a {te.fecha.max():%Y-%m-%d} ({len(te)} días)",
        },
        "caracteristicas": CARACTERISTICAS,
        "metricas": tabla,
        "modelo_elegido": elegido,
        "mejora_mae_vs_persistencia_pct": round(100 * (mae_p - mae_m) / mae_p, 1),
        "mae_m3_prueba": round(float(mean_absolute_error(
            volumen_bombeado(yte, te.t2m_hoy.values), volumen_bombeado(pred_te[elegido], te.t2m_hoy.values))), 2),
        "cuantiles_residuo_validacion": cuantiles,
        "cuantil_decision": q_opt,
        "ajuste_decision_kwh": round(ajuste, 4),
        "costo_validacion_por_cuantil": costos_q,
        "tabla_costos_prueba": tabla_costos,
        "importancia_variables": importancia,
        "serie_prueba": serie.to_dict(orient="list"),
        "escenarios": escenarios,
        "residuos_validacion": [round(float(v), 3) for v in resid],
    }
    SALIDA.mkdir(exist_ok=True)
    (SALIDA / "resultados.json").write_text(json.dumps(resultados, ensure_ascii=False, indent=1), encoding="utf-8")
    (SALIDA / "modelo.json").write_text(json.dumps(exportar_modelo(elegido, modelo)), encoding="utf-8")

    print(f"Fuente: {fuente}")
    for f in tabla:
        print(f"  {f['modelo']:<30} val MAE {f['validacion']['MAE']:.3f}  prueba MAE {f['prueba']['MAE']:.3f}"
              f"  R2 {f['prueba']['R2']:.3f}{'  <- elegido' if f['elegido'] else ''}")
    print(f"Cuantil de decisión elegido en validación: {q_opt}")
    for r in tabla_costos:
        print(f"  {r['politica']:<55} {r['costo_anual_cop']:>14,} COP/año  emergencias {r['dias_con_emergencia']}")
    print(f"Escrito {SALIDA / 'resultados.json'}")


if __name__ == "__main__":
    main()
