"""
Construye la aplicación web (un solo archivo HTML, funciona sin servidor ni internet).

Uso:
    python construir_app.py

Lee modelo/resultados.json y modelo/modelo.json (generados por pipeline.py) y,
si existen, los logos en assets/ (logo_uniguajira y logo_50_anios: .png, .jpg, .jpeg, .svg o .webp).
Escribe app/index.html. Ábrelo con doble clic en cualquier navegador.
"""
import base64
import json
import struct
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
ESTUDIANTE = "Ing. Fabián Pontón Sarmiento"
DOCENTE = "Aslin Gonzalo Botello"
CURSO = "Machine Learning aplicado a sistemas energéticos"


def cargar_logo(nombre="logo_uniguajira"):
    tipos = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
             ".svg": "image/svg+xml", ".webp": "image/webp"}
    for ext, mime in tipos.items():
        p = RAIZ / "assets" / f"{nombre}{ext}"
        if p.exists():
            return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"
    return ""


def f32(v):
    """scikit-learn compara los árboles en float32; se replica para que coincida."""
    return struct.unpack("f", struct.pack("f", v))[0]


def predecir_py(modelo, x):
    """Misma lógica que el JavaScript de la app; sirve para verificar la exportación."""
    def arbol(a):
        n = 0
        while a["l"][n] != -1:
            n = a["l"][n] if f32(x[a["f"][n]]) <= a["t"][n] else a["r"][n]
        return a["v"][n]
    if modelo["tipo"] == "gbr":
        return modelo["init"] + modelo["lr"] * sum(arbol(a) for a in modelo["arboles"])
    if modelo["tipo"] == "rf":
        return sum(arbol(a) for a in modelo["arboles"]) / len(modelo["arboles"])
    z = [(v - m) / s for v, m, s in zip(x, modelo["media"], modelo["escala"])]
    return modelo["intercepto"] + sum(c * v for c, v in zip(modelo["coef"], z))


def verificar(res, modelo):
    serie = res["serie_prueba"]
    fechas = {f: p for f, p in zip(serie["fecha"], serie["pred"])}
    peor = 0.0
    for e in res["escenarios"]:
        if e["fecha"] in fechas:
            p = predecir_py(modelo, [e[c] for c in res["caracteristicas"]])
            peor = max(peor, abs(p - fechas[e["fecha"]]))
    if peor > 0.01:
        sys.exit(f"ERROR: el modelo exportado no coincide con scikit-learn (dif. {peor:.4f}).")
    print(f"Verificación del modelo exportado: diferencia máxima {peor:.5f} kWh/m²")


def main():
    res = json.loads((RAIZ / "modelo" / "resultados.json").read_text(encoding="utf-8"))
    modelo = json.loads((RAIZ / "modelo" / "modelo.json").read_text(encoding="utf-8"))
    verificar(res, modelo)
    logo = cargar_logo()
    datos = {"res": res, "modelo": modelo, "logo": logo, "logo50": cargar_logo("logo_50_anios"),
             "estudiante": ESTUDIANTE, "docente": DOCENTE, "curso": CURSO}
    cuerpo = (RAIZ / "plantilla_app.html").read_text(encoding="utf-8")
    cuerpo = cuerpo.replace("/*__DATOS__*/null", json.dumps(datos, ensure_ascii=False).replace("</", "<\\/"))
    html = ("<!doctype html>\n<html lang=\"es\">\n<head>\n<meta charset=\"utf-8\">\n"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n"
            "</head>\n<body>\n" + cuerpo + "\n</body>\n</html>\n")
    (RAIZ / "app").mkdir(exist_ok=True)
    (RAIZ / "app" / "index.html").write_text(html, encoding="utf-8")
    print("Datos:", res["fuente_datos"])
    print("AVISO: la app mostrará el aviso de DATOS SINTÉTICOS." if res["datos_sinteticos"]
          else "La app NO muestra aviso de datos sintéticos (datos reales).")
    print("Logo:", "incluido" if logo else "no encontrado en assets/ (se muestra la sigla)")
    print("Escrito", RAIZ / "app" / "index.html")


if __name__ == "__main__":
    main()
