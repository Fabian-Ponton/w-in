"""
Genera el informe técnico y el anexo de IA en formato APA 7 (Word y PDF).

Uso:  python informes/generar_informes.py
Requiere: python-docx, matplotlib y (solo para el PDF) playwright con Chromium.
"""
import base64
import glob
import json
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent
R = json.loads((RAIZ / "modelo" / "resultados.json").read_text(encoding="utf-8"))

AUTOR = "Ing. Fabián Pontón Sarmiento"
DOCENTE = "Aslin Gonzalo Botello"
CURSO = "Machine Learning aplicado a sistemas energéticos"
FECHA = "1 de octubre de 2026"
LOGO1 = RAIZ / "assets" / "logo_uniguajira.png"
LOGO2 = RAIZ / "assets" / "logo_50_anios.png"


def m(v):
    return f"{v / 1e6:.1f}".replace(".", ",")


def c(v, d=3):
    return f"{v:.{d}f}".replace(".", ",")


# ----------------------------------------------------------------------------
# Figuras
# ----------------------------------------------------------------------------
def figuras():
    plt.rcParams.update({"font.family": "Liberation Serif", "font.size": 11,
                         "axes.spines.top": False, "axes.spines.right": False})
    gris, azul = "#b9b9b0", "#1f5fa8"
    meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
    medias = [R["exploracion"]["radiacion_mensual"][str(i)]["mean"] for i in range(1, 13)]
    s = R["sistema"]
    v_por_ghi = (s["potencia_fv_kwp"] * s["rendimiento_base"] * (1 + s["coef_temp_por_c"] * 28.435)
                 * s["eficiencia_bomba"] * 3.6e6 / (1000 * 9.81 * s["altura_dinamica_m"]))
    nivel = s["demanda_m3_dia"] / v_por_ghi
    fig, ax = plt.subplots(figsize=(6.5, 3.0), dpi=200)
    barras = ax.bar(meses, medias, color=[azul if v < nivel else gris for v in medias], width=0.65)
    ax.axhline(nivel, ls="--", color="#555555", lw=1)
    ax.text(-0.4, 6.75, f"- - -  {c(nivel, 1)} kWh/m² necesarios para bombear {s['demanda_m3_dia']:.0f} m³/día",
            ha="left", va="top", fontsize=9, color="#333333")
    ax.set_ylim(0, 7.2)
    for b_, v in zip(barras, medias):
        ax.text(b_.get_x() + b_.get_width() / 2, v - 0.45, c(v, 1), ha="center", fontsize=8.5,
                color="white" if v < nivel else "#222222")
    ax.set_ylabel("kWh/m²/día")
    fig.tight_layout()
    fig.savefig(AQUI / "figura1.png")
    plt.close(fig)

    cq = R["costo_validacion_por_cuantil"]
    qs = sorted(float(k) for k in cq)
    vals = [cq[str(q)] if str(q) in cq else cq[f"{q}"] for q in qs]
    fig, ax = plt.subplots(figsize=(6.5, 2.8), dpi=200)
    ax.plot(qs, [v / 1e6 for v in vals], color=gris, lw=2, marker="o", ms=3.5)
    qb = R["cuantil_decision"]
    vb = cq[str(qb)]
    ax.plot([qb], [vb / 1e6], "o", color=azul, ms=8)
    ax.annotate(f"Cuantil {c(qb, 2)}: ${m(vb)} M", (qb, vb / 1e6), xytext=(qb + 0.02, vb / 1e6 - 6),
                fontsize=9, fontweight="bold")
    vm = cq["0.5"]
    ax.axvline(0.5, ls="--", color="#555555", lw=1)
    ax.text(0.51, vm / 1e6 - 5, f"Pronóstico central: ${m(vm)} M", fontsize=9)
    ax.set_ylim(0, 45)
    ax.set_xlabel("Cuantil del pronóstico usado para pedir (menor = más prudente)")
    ax.set_ylabel("Millones de pesos")
    fig.tight_layout()
    fig.savefig(AQUI / "figura2.png")
    plt.close(fig)


# ----------------------------------------------------------------------------
# Contenido (lista de bloques)
# ----------------------------------------------------------------------------
def contenido_informe():
    s = R["sistema"]
    met = R["metricas"]
    tc = R["tabla_costos_prueba"]
    pers = next(t for t in tc if t["politica"].startswith("Persistencia"))
    mej = next(t for t in tc if "margen" in t["politica"])
    perf = tc[-1]
    gb = next(x for x in met if x["elegido"])
    pp = R["particion"]
    nombres = ["Sin pronóstico (solo emergencia)", "Climatología (media del mes)", "Persistencia (mañana = hoy)",
               "Gradient Boosting, pronóstico central", "Gradient Boosting + margen (cuantil 0,10)",
               "Pronóstico perfecto (límite teórico)"]
    B = []
    B.append(("titulo_texto", "Pronóstico de la radiación solar para decidir el pedido de agua en carrotanque de un acueducto solar en Uribia, La Guajira"))
    B.append(("h1", "Resumen"))
    B.append(("pnoind", f"Este proyecto usa aprendizaje automático para mejorar una decisión diaria de un acueducto comunitario con bombeo solar en Uribia: cuántos metros cúbicos de agua pedir en carrotanque programado para el día siguiente. Con 11 años de datos diarios de NASA POWER (2015-2025) se pronosticó la radiación solar del día siguiente y se convirtió en agua bombeada. El modelo elegido, Gradient Boosting, redujo el error medio un {c(R['mejora_mae_vs_persistencia_pct'], 1)} % frente a la persistencia. Usado con un margen de seguridad elegido en validación, bajó el costo simulado de carrotanques de ${m(pers['costo_anual_cop'])} a ${m(mej['costo_anual_cop'])} millones al año (un ahorro de {c(mej['ahorro_vs_persistencia_pct'], 1)} %) y los días con carrotanque de emergencia de {pers['dias_con_emergencia']} a {mej['dias_con_emergencia']} en el periodo de prueba. La principal limitación es que, con datos diarios, el modelo explica solo el {round(gb['prueba']['R2'] * 100)} % de la variación de la radiación de un día a otro."))
    B.append(("pnoind", "*Palabras clave:* bombeo solar, aprendizaje automático, Gradient Boosting, NASA POWER, La Guajira, toma de decisiones."))
    B.append(("salto", None))
    B.append(("titulo_texto", "Pronóstico de la radiación solar para decidir el pedido de agua en carrotanque de un acueducto solar en Uribia, La Guajira"))
    B.append(("p", "En la alta Guajira muchas comunidades dependen de pozos con bombas solares sin baterías: el agua del día depende del sol del día. Cuando el sol no alcanza, el faltante se cubre con carrotanque. Este informe sigue los siete pasos de la metodología del curso para mostrar si un modelo de aprendizaje automático puede mejorar esa decisión y cuánto vale hacerlo."))
    B.append(("h1", "Paso 1. Sistema elegido"))
    B.append(("p", "El sistema es un acueducto comunitario con bombeo solar en Uribia (11,71° N, 72,27° O). No se tuvo acceso a mediciones de un sistema real, por lo que se modeló con valores típicos de diseño (Tabla 1). Todos son supuestos editables en `pipeline.py`."))
    B.append(("tabla", {"n": 1, "titulo": "Supuestos del sistema de bombeo modelado",
                        "cab": ["Parámetro", "Valor supuesto"],
                        "filas": [["Generador fotovoltaico", f"{s['potencia_fv_kwp']:.0f} kWp, rendimiento {c(s['rendimiento_base'], 2)}"],
                                  ["Pérdida por temperatura", "0,4 %/°C sobre 25 °C (celda ≈ aire + 25 °C)"],
                                  ["Motobomba sumergible", f"Eficiencia {s['eficiencia_bomba'] * 100:.0f} %"],
                                  ["Altura dinámica total", f"{s['altura_dinamica_m']:.0f} m"],
                                  ["Demanda", f"{s['demanda_m3_dia']:.0f} m³/día (unas 550 personas × 60 L/día)"],
                                  ["Tanque elevado", f"{s['tanque_m3']:.0f} m³"],
                                  ["Carrotanque programado", "$30.000 por m³"],
                                  ["Carrotanque de emergencia", "$80.000 por m³"]],
                        "nota": "Valores de referencia definidos por el autor; los precios deben confirmarse con una cotización local."}))
    B.append(("p", "El volumen bombeado se calcula con la ecuación hidráulica: *V* = *E*·*η*·3,6 × 10⁶ / (*ρ*·*g*·*H*), donde *E* = *P*·*G*·*PR*·[1 − 0,004 (*T*celda − 25)] es la energía fotovoltaica del día en kWh (Duffie y Beckman, 2013). Con la radiación media de Uribia el sistema bombea unos 35 m³/día, apenas por encima de la demanda."))
    B.append(("h1", "Paso 2. Decisión y valor de mejorarla"))
    B.append(("p", "La decisión es cuántos metros cúbicos pedir hoy en carrotanque programado para mañana. La radiación es solo el paso intermedio. La decisión es asimétrica: pedir de menos obliga a un carrotanque de emergencia a $80.000/m³, mientras que pedir de más cuesta $30.000/m³ y el sobrante va al tanque si cabe. Todas las políticas comparadas usan la misma regla: pedido = máx(0, demanda − bombeo pronosticado − nivel del tanque)."))
    B.append(("p", f"En el periodo de prueba, la regla de persistencia cuesta ${m(pers['costo_anual_cop'])} millones al año y un pronóstico perfecto costaría ${m(perf['costo_anual_cop'])} millones. Hay hasta ${m(pers['costo_anual_cop'] - perf['costo_anual_cop'])} millones al año en juego, además de los días en que la comunidad se queda sin agua."))
    B.append(("h1", "Paso 3. Datos"))
    B.append(("p", f"Se usaron datos públicos y reales de NASA POWER (National Aeronautics and Space Administration [NASA], 2026): la serie diaria del punto de Uribia entre el 1 de enero de 2015 y el 31 de diciembre de 2025, con 4.018 días. Las variables son la radiación global horizontal (ALLSKY_SFC_SW_DWN), la temperatura, el viento y la humedad relativa a 2 m y la precipitación corregida. Son estimaciones satelitales y de reanálisis en una celda de unos 50 km, no mediciones de una estación en el sitio."))
    B.append(("h1", "Paso 4. Exploración y limpieza"))
    B.append(("p", "La serie llegó completa: no hubo valores faltantes (−999), días ausentes ni radiaciones fuera del rango físico. La única decisión con efecto fue la lluvia extrema: cinco días superaron el percentil 99,9 (126,5 mm), con un máximo de 439 mm el 22 de mayo de 2024. Se conservaron porque forman parte de un evento de varios días y no parecen un error, pero se usó log(1 + lluvia) para que un solo día no dominara el modelo. El código deja preparada una interpolación lineal de hasta tres días para archivos futuros con faltantes."))
    B.append(("p", "La Figura 1 muestra el hallazgo central de la exploración: octubre, noviembre y diciembre no alcanzan la radiación que exige la demanda, justo los meses en que hace falta el carrotanque. Además, la radiación de hoy se parece solo en parte a la de mañana (autocorrelación de 0,53), por lo que la persistencia es una línea base razonable y difícil de superar."))
    B.append(("figura", {"n": 1, "titulo": "Radiación media diaria por mes en Uribia, 2015-2025", "img": AQUI / "figura1.png",
                         "nota": "Las barras azules están por debajo de la radiación necesaria para bombear la demanda diaria con los supuestos de la Tabla 1. Datos de NASA (2026)."}))
    B.append(("h1", "Paso 5. Línea base y modelo"))
    B.append(("p", "El modelo pronostica la radiación de mañana con lo que el operador sabe en la tarde de hoy: radiación de hoy, ayer y anteayer; media y desviación de los últimos siete días; temperatura, humedad, viento y lluvia de hoy; el cambio de humedad respecto a ayer, y el día del año codificado con seno y coseno. Como líneas base se usaron la persistencia («mañana será igual que hoy»), que exige el curso, y la climatología mensual (Hyndman y Athanasopoulos, 2021)."))
    B.append(("p", f"Se compararon una regresión Ridge, Random Forest (Breiman, 2001) y Gradient Boosting (Friedman, 2001), implementados en scikit-learn (Pedregosa et al., 2011). La regla de selección, fijada de antemano, fue el menor error absoluto medio (MAE) en validación. Gradient Boosting ({c(gb['validacion']['MAE'])}) superó por poco a Random Forest ({c(met[3]['validacion']['MAE'])}); además, su modelo exportado es más liviano para la aplicación. La variable más importante fue la radiación de hoy (62 % de la importancia). Con los errores de validación se estimó la incertidumbre: el 80 % de los días la radiación real cae entre −1,01 y +0,88 kWh/m² del pronóstico."))
    B.append(("h1", "Paso 6. Evaluación con datos nuevos"))
    B.append(("p", f"La partición fue cronológica 60/20/20, nunca aleatoria, para que el modelo no viera el futuro: entrenamiento del {pp['entrenamiento'].split(' (')[0].replace(' a ', ' al ')}, validación del {pp['validacion'].split(' (')[0].replace(' a ', ' al ')} y prueba del {pp['prueba'].split(' (')[0].replace(' a ', ' al ')}. La Tabla 2 resume los errores."))
    B.append(("tabla", {"n": 2, "titulo": "Error de pronóstico de la radiación del día siguiente",
                        "cab": ["Modelo", "MAE validación", "MAE prueba", "RMSE prueba", "R² prueba"],
                        "filas": [[x["modelo"] + (" (base)" if x["tipo"] == "línea base" else "") + (" (elegido)" if x["elegido"] else ""),
                                   c(x["validacion"]["MAE"]), c(x["prueba"]["MAE"]), c(x["prueba"]["RMSE"]), c(x["prueba"]["R2"], 2)] for x in met],
                        "nota": "MAE y RMSE en kWh/m²/día. El modelo se eligió con validación; la prueba solo se usó al final."}))
    B.append(("p", f"En prueba, Gradient Boosting se equivocó en promedio {c(gb['prueba']['MAE'])} kWh/m²/día, un {c(R['mejora_mae_vs_persistencia_pct'], 1)} % menos que la persistencia, lo que equivale a {c(R['mae_m3_prueba'], 1)} m³/día de agua. Random Forest quedó apenas mejor en prueba (0,584), pero cambiar de modelo después de ver la prueba sería un sesgo de selección."))
    B.append(("p", "Un mejor MAE no garantiza una mejor decisión. Pedir con el pronóstico central resultó más caro que la persistencia, porque el modelo suaviza los días extremos. Como un metro cúbico faltante cuesta 2,7 veces más que uno sobrante, conviene pedir con un pronóstico prudente: un cuantil bajo de la distribución de errores. El cuantil se eligió en validación (Figura 2); el mínimo fue 0,10, es decir, el pronóstico menos 1,01 kWh/m²."))
    B.append(("figura", {"n": 2, "titulo": "Costo simulado de carrotanques en validación según el cuantil del pronóstico", "img": AQUI / "figura2.png",
                         "nota": "Costo total en los 802 días de validación, en millones de pesos colombianos."}))
    B.append(("p", "Con ese margen fijo, la simulación día a día del periodo de prueba, con el tanque de 20 m³, arroja los costos de la Tabla 3."))
    B.append(("tabla", {"n": 3, "titulo": "Costo de cada política de pedido en el periodo de prueba",
                        "cab": ["Política de pedido", "Costo anual (millones $)", "Días con emergencia", "m³ de emergencia", "Frente a persistencia"],
                        "filas": [[nm, m(t["costo_anual_cop"]), str(t["dias_con_emergencia"]), f"{t['m3_emergencia']:.0f}",
                                   f"{'+' if t['ahorro_vs_persistencia_pct'] > 0 else ''}{c(t['ahorro_vs_persistencia_pct'], 1)} %"] for nm, t in zip(nombres, tc)],
                        "nota": f"Periodo de prueba de {pp['prueba'].split('(')[1].rstrip(')')}, anualizado. Un valor positivo indica ahorro."}))
    B.append(("p", f"El modelo con margen ahorra ${m(pers['costo_anual_cop'] - mej['costo_anual_cop'])} millones al año, reduce los días de emergencia de {pers['dias_con_emergencia']} a {mej['dias_con_emergencia']} y recupera el 36 % de la brecha entre la persistencia y el pronóstico perfecto."))
    B.append(("h1", "Paso 7. Comunicación de la decisión"))
    B.append(("p", "La aplicación web es un solo archivo (`app/index.html`) que funciona sin servidor y evalúa el modelo real en el navegador. Sigue el esquema dato → modelo → salida → decisión en cinco pestañas: el escenario de hoy (un día real del periodo de prueba, un archivo CSV de NASA POWER, el clima más reciente consultado a NASA o valores escritos a mano), el pronóstico con su banda del 80 % dibujado como un tanque frente a la demanda, la decisión explícita («programa un carrotanque de X m³») en una tarjeta verde, amarilla o roja con su probabilidad de faltante, una nota de transparencia con los datos, el error, los costos y los límites, y una simulación animada hora por hora del sistema (sol, paneles, variador, bomba, tanque, comunidad y carrotanque). Cada simulación queda registrada y se descarga como informe en Word y en Excel. Para reentrenar con datos de 2026 en adelante basta con ejecutar `python pipeline.py --descargar`."))
    B.append(("p", "Los límites declarados son cuatro. Solo pronostica el día siguiente con datos diarios, sin nubes en tiempo real ni pronósticos meteorológicos. Los días muy nublados de octubre y noviembre son los que peor predice. El bombeo sale de un modelo físico simplificado y no de mediciones del pozo. Por último, los precios y el tamaño del sistema son supuestos de referencia. La aplicación es un apoyo: el operador conserva su criterio ante una falla de la bomba o un evento en la comunidad."))
    B.append(("h1", "Conclusiones y decisiones clave"))
    B.append(("p", "**Por qué Gradient Boosting.** La relación entre el clima de hoy y la radiación de mañana no es lineal, y los modelos de árboles la captan mejor que Ridge. Entre los dos modelos de árboles decidió la regla fijada de antemano."))
    B.append(("p", "**Cómo se trató el dato atípico.** La lluvia de 439 mm no se borró, porque forma parte de un evento de cinco días; se transformó con log(1 + lluvia)."))
    B.append(("p", "**Por qué la métrica final está en pesos.** El modelo con mejor MAE, usado tal cual, costaba $2,5 millones al año más que la persistencia. Medir en pesos mostró que había que pedir con margen, y ese cambio convirtió una pérdida en un ahorro de 14 %."))
    B.append(("salto", None))
    B.append(("h1", "Referencias"))
    for ref in REFERENCIAS:
        B.append(("ref", ref))
    return B


REFERENCIAS = [
    "Breiman, L. (2001). Random forests. *Machine Learning, 45*(1), 5-32. https://doi.org/10.1023/A:1010933404324",
    "Duffie, J. A. y Beckman, W. A. (2013). *Solar engineering of thermal processes* (4.ª ed.). John Wiley & Sons. https://doi.org/10.1002/9781118671603",
    "Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. *The Annals of Statistics, 29*(5), 1189-1232. https://doi.org/10.1214/aos/1013203451",
    "Hyndman, R. J. y Athanasopoulos, G. (2021). *Forecasting: Principles and practice* (3.ª ed.). OTexts. https://otexts.com/fpp3/",
    "National Aeronautics and Space Administration. (2026). *Prediction of Worldwide Energy Resources (POWER): Datos diarios del punto 11,71° N, 72,27° O, 2015-2025* [Conjunto de datos]. NASA Langley Research Center. https://power.larc.nasa.gov/",
    "Pedregosa, F., Varoquaux, G., Gramfort, A., Michel, V., Thirion, B., Grisel, O., Blondel, M., Prettenhofer, P., Weiss, R., Dubourg, V., Vanderplas, J., Passos, A., Cournapeau, D., Brucher, M., Perrot, M. y Duchesnay, É. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research, 12*, 2825-2830.",
]


def contenido_anexo():
    B = []
    B.append(("titulo_texto", "Anexo: uso de inteligencia artificial generativa"))
    B.append(("p", "El código, la aplicación web y el borrador del informe se elaboraron con ayuda de Claude (Anthropic, 2026), un modelo de lenguaje de gran tamaño, usado el 1 de octubre de 2026. Las decisiones sobre el sistema, los supuestos y la entrega final son responsabilidad del autor. La Tabla A1 reproduce las peticiones enviadas."))
    B.append(("tabla", {"n": "A1", "titulo": "Peticiones (prompts) enviadas al asistente",
                        "cab": ["N.º", "Petición, copiada tal cual", "Adjunto"],
                        "filas": [["1", "«Este es mi proyecto final de ML (bombeo solar en Uribia, La Guajira). Lee README.md. En la carpeta datos está el CSV real de NASA POWER. Ejecuta python pipeline.py datos/<nombre del csv> y luego python construir_app.py. Instala con pip lo que falte. Revisa que la app ya no muestre el aviso de datos sintéticos y resúmeme las métricas y la tabla de costos en modelo/resultados.json.»", "Ninguno"],
                                  ["2", "(Archivo enviado sin texto)", "CSV diario de NASA POWER 2015-2025"],
                                  ["3", "«Esto es lo que me pide el docente llamado aslin Gonzalo Botello, me gustaria que llevara el logo de la universidad»", "Fotos del enunciado en Moodle"],
                                  ["4", "«Hazlo todo y hazme entrega»", "Ninguno"],
                                  ["5", "«me gustaria que la app tenga los datos actualizados ya que estamos en el 2026 y vamos hacia el 2027, esta aplicacion no se le actuliaza la informacion de ninguna manera ?»", "Ninguno"],
                                  ["6", "«el informe debe llevar estos logos y cumplir con las normas APA , mi nombre es fabian ponton sarmiento ingeniero. ademas esta aplicacion la puedo usar en mi iphone ? como la descargo en mi iphone?»", "Logos de la universidad"],
                                  ["7", "«https://claude.ai/artifact/YHc31Pe7AbMfw4LbuFF1pv esta es la misma pero realizada en chat, quiero que la que hiciste fuera como esta»", "Versión propia de la app hecha en el chat"],
                                  ["8", "«Observo que en las 5 pantallas aparece la misma imagen o simulacion, en la 1 dejala , en la 2,3,4,5 coloca imagenes que tengan relacion con cada titulo, necesito que al final la aplicacion entregue un informe en work y excel donde spique con detalles los resultados que arroje cada simulacion»", "Fotos de la app en pantalla"],
                                  ["9", "«quita esa leyenda de las imagnes 2,3,4,5, dejala solo en la primera»", "Captura del encabezado"],
                                  ["10", "«Necesito que revises esta informacion y me entregas lo que el docente solicita, todo bajo la norma y con los logos de la unuvrsidad»", "Fotos del enunciado en Moodle"]],
                        "nota": "Como los guiones originales no llegaron al asistente, este construyó desde cero pipeline.py, construir_app.py y la aplicación siguiendo el enunciado."}))
    B.append(("p", "La Tabla A2 resume lo que se corrigió de las respuestas del asistente durante el trabajo."))
    B.append(("tabla", {"n": "A2", "titulo": "Correcciones hechas a las respuestas",
                        "cab": ["Primera versión", "Problema", "Corrección"],
                        "filas": [["Demanda de 30 m³/día y tanque de 30 m³", "El sistema sobraba casi siempre y la decisión no cambiaba nada", "Demanda de 33 m³/día y tanque de 20 m³"],
                                  ["Política «pedido fijo de 5 m³ diarios»", "Comparación de paja ($54,8 millones al año)", "Se reemplazó por la climatología mensual"],
                                  ["«Pronóstico perfecto» con 6 días de emergencia", "Usaba la temperatura de hoy en vez de la de mañana", "Ahora usa la temperatura real y da 0 emergencias"],
                                  ["Pedido con el pronóstico central", "Costaba más que la persistencia", "Margen de seguridad elegido en validación"],
                                  ["Aplicación en celular", "La página se desbordaba a lo ancho", "Diseño ajustado y probado a 400 px"],
                                  ["Datos fijos hasta 2025", "La aplicación no se actualizaba", "Botón de consulta a NASA POWER y opción --descargar"],
                                  ["Informe sin formato APA", "No cumplía la norma pedida", "Este documento, en formato APA 7"],
                                  ["Árboles evaluados en el navegador con doble precisión", "En 6 de 803 días el pronóstico difería hasta 0,02 kWh/m² del de scikit-learn", "Se replican las comparaciones en float32 de scikit-learn (Math.fround)"],
                                  ["Tarjeta de decisión con «costo esperado del día»", "En algunos días el costo esperado de pedir superaba el de no pedir, porque ignoraba que el agua sobrante queda en el tanque", "Se muestra el costo del pedido y el de una emergencia en un día nublado (P10)"]],
                        "nota": "El script construir_app.py verifica en cada ejecución que el modelo exportado dé el mismo pronóstico que scikit-learn."}))
    B.append(("h1", "Referencia"))
    B.append(("ref", "Anthropic. (2026). *Claude* (versión del 1 de octubre de 2026) [Modelo de lenguaje de gran tamaño]. https://claude.ai"))
    return B


def contenido_guion():
    tc = R["tabla_costos_prueba"]
    pers = next(t for t in tc if t["politica"].startswith("Persistencia"))
    mej = next(t for t in tc if "margen" in t["politica"])
    med = next(t for t in tc if "mediana" in t["politica"])
    gb = next(x for x in R["metricas"] if x["elegido"])
    B = []
    B.append(("titulo_texto", "Guion de la sustentación oral"))
    B.append(("p", "La sustentación es individual, dura entre 8 y 10 minutos e incluye una demostración en vivo de la aplicación y la explicación de tres decisiones clave del proyecto. La Tabla G1 reparte el tiempo; la aplicación debe estar abierta antes de empezar, en la pestaña 1."))
    B.append(("tabla", {"n": "G1", "titulo": "Orden y tiempo de la sustentación",
        "cab": ["Minuto", "Qué mostrar", "Qué decir"],
        "filas": [
            ["0:00-1:00", "Portada de la aplicación (pestaña 1)", "El acueducto comunitario de Uribia bombea con 3 kWp de paneles. Cada tarde el operador decide si pide un carrotanque para mañana: pedirlo hoy cuesta $30.000/m³ y uno de emergencia $80.000/m³."],
            ["1:00-2:00", "Pestaña 1: elegir el último día de prueba", "El modelo usa el clima de hoy y la radiación de los siete días anteriores, datos de NASA POWER 2015-2025 para el punto de Uribia."],
            ["2:00-3:30", "Pestaña 2: tanque y tabla P10, P50 y P90", f"El pronóstico más probable se convierte en metros cúbicos. La banda P10-P90 sale de los errores reales del modelo en validación."],
            ["3:30-5:00", "Pestaña 3: tarjeta de decisión", "La aplicación no se queda en el pronóstico: dice cuántos metros cúbicos pedir, con qué probabilidad faltaría agua y cuánto cuesta."],
            ["5:00-6:30", "Pestaña 5: reproducir el día; cambiar a P10", "Si el día sale más nublado se ve si el carrotanque programado alcanza. Al final se descarga el informe en Word y Excel."],
            ["6:30-9:00", "Pestaña 4: tablas de error y de costos", f"Las tres decisiones clave (sección siguiente) y el límite del modelo."],
            ["9:00-10:00", "Pestaña 4: límites conocidos", "Cierre: qué decisión cambia gracias al modelo y qué no puede prometer."]],
        "nota": "Si no hay internet, la aplicación funciona igual abriendo app/index.html; solo el botón de NASA POWER necesita conexión."}))
    B.append(("h1", "Decisión clave 1: por qué Gradient Boosting y no otro algoritmo"))
    B.append(("p", f"La pregunta es de regresión: cuánta radiación habrá mañana. La relación entre el clima de hoy y la de mañana no es lineal, por eso se compararon Ridge (lineal), Random Forest y Gradient Boosting contra dos líneas base. La regla, fijada antes de mirar la prueba, fue elegir el menor MAE en validación: Gradient Boosting obtuvo {c(gb['validacion']['MAE'])} kWh/m². En prueba reduce el error {c(R['mejora_mae_vs_persistencia_pct'],1)} % frente a la persistencia. Random Forest quedó casi igual en prueba, y se dice con honestidad: la elección no se cambió después de ver la prueba."))
    B.append(("h1", "Decisión clave 2: cómo se trataron los datos faltantes y atípicos"))
    B.append(("p", "Se revisaron 4.018 días. No hubo días ausentes ni valores -999, así que no hizo falta interpolar; la regla preparada era interpolar huecos de hasta tres días. La lluvia de 439 mm del 22 de mayo de 2024 no se borró, porque forma parte de un evento real de cinco días; se usó log(1 + lluvia) para que no dominara al modelo. La partición fue cronológica 60/20/20, nunca aleatoria, para no usar el futuro para predecir el pasado."))
    B.append(("h1", "Decisión clave 3: por qué la métrica final está en pesos"))
    B.append(("p", f"El MAE en kWh/m² no dice cuánto se ahorra. Al simular el periodo de prueba en pesos, pedir con el pronóstico central costaba {m(med['costo_anual_cop'])} millones al año, más que la persistencia ({m(pers['costo_anual_cop'])} millones), porque quedarse corto cuesta casi tres veces más que pedir de más. Por eso se pide con un margen de seguridad (cuantil {c(R['cuantil_decision'],2)} de los errores, elegido en validación): el costo baja a {m(mej['costo_anual_cop'])} millones al año y los días con emergencia pasan de {pers['dias_con_emergencia']} a {mej['dias_con_emergencia']}."))
    B.append(("h1", "Preguntas probables"))
    B.append(("tabla", {"n": "G2", "titulo": "Respuestas cortas a preguntas probables del docente",
        "cab": ["Pregunta", "Respuesta"],
        "filas": [
            ["¿Por qué no un R² más alto?", f"La radiación de mañana depende de nubes que los datos diarios no anticipan; R² de {c(gb['prueba']['R2'],2)} es razonable para un día de anticipación. Lo que importa es que la decisión ahorra dinero."],
            ["¿El modelo es causal?", "No. Aprende asociaciones entre el clima de hoy y la radiación de mañana; sirve para pronosticar, no para explicar por qué cambia el clima."],
            ["¿Cómo se actualiza?", "Con python pipeline.py --descargar se bajan los datos nuevos de NASA POWER y se reentrena; la aplicación también trae el clima reciente con un botón."],
            ["¿Qué pasa si los precios cambian?", "Los costos están en un solo lugar del código; al cambiarlos se vuelve a elegir el margen en validación."],
            ["¿Qué haría con más tiempo?", "Medir el caudal real de la bomba y usar pronósticos meteorológicos o imágenes de satélite."]],
        "nota": "Los valores provienen de modelo/resultados.json, generado por pipeline.py."}))
    return B


# ----------------------------------------------------------------------------
# Salida HTML -> PDF (Chromium)
# ----------------------------------------------------------------------------
def md_html(t):
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\*(.+?)\*", r"<i>\1</i>", t)
    t = re.sub(r"`(.+?)`", r"<span class='code'>\1</span>", t)
    return t


def b64(p):
    return "data:image/png;base64," + base64.b64encode(Path(p).read_bytes()).decode()


def portada_html(titulo, sub=None):
    return f"""<section class="portada">
<div class="logos"><img src="{b64(LOGO1)}" style="height:1.5in"><img src="{b64(LOGO2)}" style="height:1.15in"></div>
<p class="tit"><b>{titulo}</b></p>{f'<p class="c">{sub}</p>' if sub else ''}
<p class="c"><br></p>
<p class="c">{AUTOR}</p><p class="c">Universidad de La Guajira</p><p class="c">{CURSO}</p>
<p class="c">Docente: {DOCENTE}</p><p class="c">{FECHA}</p></section>"""


def a_html(bloques, titulo_portada, sub=None):
    h = [portada_html(titulo_portada, sub)]
    for tipo, v in bloques:
        if tipo == "titulo_texto":
            h.append(f'<p class="tit2"><b>{md_html(v)}</b></p>')
        elif tipo == "h1":
            h.append(f"<h1>{md_html(v)}</h1>")
        elif tipo == "p":
            h.append(f"<p class='p'>{md_html(v)}</p>")
        elif tipo == "pnoind":
            h.append(f"<p class='p ni'>{md_html(v)}</p>")
        elif tipo == "salto":
            h.append("<div class='salto'></div>")
        elif tipo == "ref":
            h.append(f"<p class='ref'>{md_html(v)}</p>")
        elif tipo == "tabla":
            filas = "".join("<tr>" + "".join(f"<td>{md_html(x)}</td>" for x in f) + "</tr>" for f in v["filas"])
            h.append(f"""<div class="obj"><p class="num"><b>Tabla {v['n']}</b></p><p class="otit"><i>{v['titulo']}</i></p>
<table><thead><tr>{''.join(f'<th>{x}</th>' for x in v['cab'])}</tr></thead><tbody>{filas}</tbody></table>
<p class="nota"><i>Nota.</i> {md_html(v['nota'])}</p></div>""")
        elif tipo == "figura":
            h.append(f"""<div class="obj"><p class="num"><b>Figura {v['n']}</b></p><p class="otit"><i>{v['titulo']}</i></p>
<img src="{b64(v['img'])}" style="width:6.3in"><p class="nota"><i>Nota.</i> {md_html(v['nota'])}</p></div>""")
    css = """@page{size:letter;margin:1in}
body{font-family:'Times New Roman','Liberation Serif',serif;font-size:12pt;line-height:2;color:#000;margin:0}
p{margin:0}.p{text-indent:.5in}.ni{text-indent:0}.c{text-align:center}
.portada{height:9in;display:flex;flex-direction:column;justify-content:flex-start;break-after:page}
.logos{display:flex;justify-content:space-between;align-items:center;margin-bottom:.6in}
.tit{text-align:center;margin-top:.4in;margin-bottom:.2in}.tit2{text-align:center}
h1{font-size:12pt;text-align:center;font-weight:bold;margin:0;line-height:2;break-after:avoid}
.ref{padding-left:.5in;text-indent:-.5in;overflow-wrap:anywhere}
.salto{break-after:page}
.obj{break-inside:avoid;margin:6pt 0}.num{margin-top:6pt}.otit{margin-bottom:4pt}
table{border-collapse:collapse;width:100%;font-size:11pt;line-height:1.25}
th{border-top:1px solid #000;border-bottom:1px solid #000;text-align:left;padding:4px 6px;font-weight:normal}
td{padding:4px 6px;vertical-align:top}tbody tr:last-child td{border-bottom:1px solid #000}
.nota{font-size:11pt;line-height:1.5;margin-top:4pt}.code{font-family:'Courier New','Liberation Mono',monospace;font-size:10.5pt}"""
    return f"<!doctype html><html lang='es'><head><meta charset='utf-8'><style>{css}</style></head><body>{''.join(h)}</body></html>"


def a_pdf(html, salida):
    from playwright.sync_api import sync_playwright
    tmp = salida.with_suffix(".html")
    tmp.write_text(html, encoding="utf-8")
    exe = (glob.glob("/opt/pw-browsers/chromium-*/chrome-linux/chrome") or [None])[0]
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=exe) if exe else p.chromium.launch()
        pg = b.new_page()
        pg.goto(tmp.as_uri())
        pg.pdf(path=str(salida), format="Letter", display_header_footer=True,
               header_template="<div style='font-family:Times New Roman,Liberation Serif,serif;font-size:12pt;width:100%;text-align:right;margin-right:1in'><span class='pageNumber'></span></div>",
               footer_template="<div></div>", margin={"top": "1in", "bottom": "1in", "left": "1in", "right": "1in"})
        b.close()
    tmp.unlink()


# ----------------------------------------------------------------------------
# Salida Word (APA 7)
# ----------------------------------------------------------------------------
def runs(par, texto, tam=None):
    for trozo in re.split(r"(\*\*.+?\*\*|\*.+?\*|`.+?`)", texto):
        if not trozo:
            continue
        if trozo.startswith("**"):
            r = par.add_run(trozo[2:-2]); r.bold = True
        elif trozo.startswith("*"):
            r = par.add_run(trozo[1:-1]); r.italic = True
        elif trozo.startswith("`"):
            r = par.add_run(trozo[1:-1]); r.font.name = "Courier New"
        else:
            r = par.add_run(trozo)
        if tam:
            r.font.size = Pt(tam)


def numero_pagina(section):
    p = section.header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p.add_run()
    for tag, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), tag)
        else:
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt
        r._r.append(e)


def borde(celda, lado):
    tcPr = celda._tc.get_or_add_tcPr()
    b = tcPr.find(qn("w:tcBorders"))
    if b is None:
        b = OxmlElement("w:tcBorders"); tcPr.append(b)
    e = OxmlElement(f"w:{lado}")
    e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "6"); e.set(qn("w:color"), "000000")
    b.append(e)


def a_docx(bloques, titulo_portada, salida, sub=None):
    d = Document()
    st = d.styles["Normal"]
    st.font.name = "Times New Roman"; st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.DOUBLE; pf.space_after = Pt(0); pf.space_before = Pt(0)
    sec = d.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    for lado in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, lado, Inches(1))
    numero_pagina(sec)

    t = d.add_table(rows=1, cols=2)
    t.cell(0, 0).paragraphs[0].add_run().add_picture(str(LOGO1), height=Inches(1.5))
    c2 = t.cell(0, 1).paragraphs[0]; c2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    c2.add_run().add_picture(str(LOGO2), height=Inches(1.15))
    for _ in range(2):
        d.add_paragraph()
    p = d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; r = p.add_run(titulo_portada); r.bold = True
    if sub:
        p = d.add_paragraph(sub); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    d.add_paragraph()
    for linea in (AUTOR, "Universidad de La Guajira", CURSO, f"Docente: {DOCENTE}", FECHA):
        p = d.add_paragraph(linea); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    d.add_page_break()

    for tipo, v in bloques:
        if tipo == "titulo_texto":
            p = d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; runs(p, f"**{v}**")
        elif tipo == "h1":
            p = d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.keep_with_next = True; r = p.add_run(v); r.bold = True
        elif tipo in ("p", "pnoind"):
            p = d.add_paragraph()
            if tipo == "p":
                p.paragraph_format.first_line_indent = Inches(0.5)
            runs(p, v)
        elif tipo == "salto":
            d.add_page_break()
        elif tipo == "ref":
            p = d.add_paragraph(); p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.5); runs(p, v)
        elif tipo in ("tabla", "figura"):
            nombre = "Tabla" if tipo == "tabla" else "Figura"
            p = d.add_paragraph(); r = p.add_run(f"{nombre} {v['n']}"); r.bold = True
            p.paragraph_format.keep_with_next = True
            p = d.add_paragraph(); r = p.add_run(v["titulo"]); r.italic = True
            p.paragraph_format.keep_with_next = True
            if tipo == "tabla":
                tb = d.add_table(rows=1 + len(v["filas"]), cols=len(v["cab"]))
                tb.alignment = WD_TABLE_ALIGNMENT.LEFT
                for j, x in enumerate(v["cab"]):
                    cel = tb.cell(0, j); cel.text = ""
                    pp = cel.paragraphs[0]; pp.paragraph_format.line_spacing = 1.0; runs(pp, x, 11)
                    borde(cel, "top"); borde(cel, "bottom")
                for i, f in enumerate(v["filas"], 1):
                    for j, x in enumerate(f):
                        cel = tb.cell(i, j); cel.text = ""
                        pp = cel.paragraphs[0]; pp.paragraph_format.line_spacing = 1.0; runs(pp, x, 11)
                        if i == len(v["filas"]):
                            borde(cel, "bottom")
            else:
                p = d.add_paragraph(); p.add_run().add_picture(str(v["img"]), width=Inches(6.3))
            p = d.add_paragraph(); p.paragraph_format.line_spacing = 1.5
            r = p.add_run("Nota. "); r.italic = True; r.font.size = Pt(11)
            runs(p, v["nota"], 11)
    d.save(salida)


def main():
    figuras()
    inf, anx = contenido_informe(), contenido_anexo()
    t_inf = "Pronóstico de la radiación solar para decidir el pedido de agua en carrotanque de un acueducto solar en Uribia, La Guajira"
    t_anx = "Anexo: uso de inteligencia artificial generativa"
    sub_anx = "Proyecto final: pedido de agua en carrotanque en Uribia"
    a_docx(inf, t_inf, RAIZ / "Informe_tecnico_APA.docx")
    a_docx(anx, t_anx, RAIZ / "Anexo_IA_generativa_APA.docx", sub_anx)
    a_pdf(a_html(inf, t_inf), RAIZ / "Informe_tecnico_APA.pdf")
    a_pdf(a_html(anx, t_anx, sub_anx), RAIZ / "Anexo_IA_generativa_APA.pdf")
    gui = contenido_guion(); t_gui = "Guion de la sustentación oral"; sub_gui = "Proyecto final: pedido de agua en carrotanque en Uribia"
    a_docx(gui, t_gui, RAIZ / "Guion_sustentacion_APA.docx", sub_gui)
    a_pdf(a_html(gui, t_gui, sub_gui), RAIZ / "Guion_sustentacion_APA.pdf")
    print("Escritos Informe_tecnico_APA (.docx/.pdf) y Anexo_IA_generativa_APA (.docx/.pdf)")


if __name__ == "__main__":
    main()
