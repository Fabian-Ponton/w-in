# ¿Cuánta agua pedir en carrotanque para mañana?
Proyecto final · Machine Learning aplicado a sistemas energéticos · Universidad de La Guajira
Estudiante: Ing. Fabián Pontón Sarmiento · Docente: Aslin Gonzalo Botello

## Decisión que mejora
Cada tarde, el operador de un acueducto solar en Uribia (La Guajira) decide cuántos m³ pedir en carrotanque programado
para el día siguiente. Si pide de menos, falta agua y toca un carrotanque de emergencia (más caro). Si pide de más, paga
agua que no hacía falta. El modelo pronostica la radiación solar de mañana, la convierte en m³ bombeados y recomienda el pedido.

## Cómo ejecutarlo
```bash
pip install -r requirements.txt
python pipeline.py datos/POWER_Point_Daily_20150101_20251231_011d71N_072d27W_LST.csv
python construir_app.py
```
Después abre `app/index.html` con doble clic (no necesita servidor ni internet).
## Cómo actualizar los datos (2026 en adelante)
- **Clima de hoy en la app:** el botón "Traer el clima más reciente de NASA POWER" consulta la API pública de NASA y carga el último día publicado (NASA publica con algunos días de retraso). Necesita internet; el modelo no cambia.
- **Reentrenar con datos nuevos:** `python pipeline.py --descargar` baja la serie 2015-hoy a `datos/`, recorta los días que NASA aún no publica y reentrena; luego `python construir_app.py`. Conviene hacerlo cada pocos meses.

Si ejecutas `python pipeline.py` sin CSV, se usan datos sintéticos y la app lo advierte con un aviso rojo.

Para poner el logo de la universidad, guarda la imagen como `assets/logo_uniguajira.png` (o .jpg/.svg) y vuelve a ejecutar `python construir_app.py`.

## Los siete pasos
1. **Sistema:** bombeo solar de agua comunitario en Uribia (3 kWp, bomba sumergible, altura dinámica de 60 m, tanque de 20 m³, 33 m³/día).
2. **Decisión:** m³ de carrotanque programado para mañana. Programado: $30.000/m³; emergencia: $80.000/m³ (supuestos editables en `pipeline.py`).
3. **Datos:** NASA POWER diario real (2015-2025, lat 11.71, lon -72.27): radiación, temperatura, humedad, viento y lluvia.
4. **Exploración y limpieza:** faltantes -999, huecos de calendario, rangos físicos y lluvia extrema (439 mm el 2024-05-22, que se conserva y se transforma con log(1+p)). El registro completo queda en `modelo/resultados.json` y en la app.
5. **Línea base y modelo:** persistencia ("mañana = hoy") y climatología mensual contra Ridge, Random Forest y Gradient Boosting. Se elige el de menor MAE en validación.
6. **Evaluación:** partición cronológica 60/20/20. Las métricas se dan en kWh/m², en m³ y en pesos con una simulación día a día con tanque.
7. **Comunicación:** la app web tiene escenario de entrada, salida con incertidumbre, decisión explícita y nota de transparencia.

## Archivos
- `pipeline.py`: limpieza, modelos, incertidumbre, simulación de costos y exportación.
- `construir_app.py` + `plantilla_app.html`: generan `app/index.html` con el modelo embebido (el navegador evalúa los árboles).
- `modelo/resultados.json`: métricas, tabla de costos y datos de la app. `modelo/modelo.json`: modelo exportado.

## Documentos de la entrega (formato APA 7)
- `Informe_tecnico_APA.pdf` / `.docx`: informe técnico (9 páginas con portada y referencias): los siete pasos, la limpieza, la comparación contra la línea base y las métricas.
- `Anexo_IA_generativa_APA.pdf` / `.docx`: peticiones usadas con IA generativa y lo que se corrigió.
- `informes/generar_informes.py` vuelve a generar ambos a partir de `modelo/resultados.json`.

## Informe de resultados desde la app

En la pestaña 5 (Simulación), la sección «Informe de resultados» guarda cada simulación calculada en la sesión y permite descargar:

- un informe en Word (.docx) con los logos, el resumen, el detalle de cada simulación (entradas, pronóstico P10/P50/P90, decisión, resultado por escenario y balance hora por hora), la confiabilidad del modelo y la nota de transparencia;
- un libro de Excel (.xlsx) con las hojas Resumen, Escenarios, Horario P50, Entradas y Modelo y costos.

Ambos archivos se generan en el navegador, sin internet.
